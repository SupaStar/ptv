<?php $__env->startSection('titulo', "Productos"); ?>
<?php $__env->startSection('contenido'); ?>
<div class="container-fluid">
<div class="row mt-5">
    <div class="col-12">
        <table class="table table-striped table-bordered responsive nowrap" id="tabla-producto" style="width:100%">
            <thead>
                <tr>
                    <th hidden>Folio</th>
                    <th>Nombre</th>
                    <th >Compra</th>
                    <th >Venta</th>
                    <th >Stock</th>
                    <th >Acciones</th>
                </tr>
            </thead>
            <tbody id="tbproducto">



            </tbody>
        </table>
    </div>
</div>
<input type="hidden" id="ruta-editar-precio" value="<?php echo e(route('productos.editar-precio')); ?>">
<input type="hidden" id="ruta-editar-nombre" value="<?php echo e(route('productos.editar-nombre')); ?>">
<input type="hidden" id="ruta-editar-stock" value="<?php echo e(route('productos.editar-stock')); ?>">
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="/js/es.js?v=<?php echo e(config("app.version")); ?>"></script>
<script src="/js/producto.js?v=<?php echo e(config("app.version")); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>