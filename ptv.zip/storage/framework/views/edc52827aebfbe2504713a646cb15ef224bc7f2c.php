<?php $__env->startSection('titulo', "Productos"); ?>
<?php $__env->startSection('contenido'); ?>
<form class="col-6 offset-3" method="POST">
    <?php echo e(csrf_field()); ?>

    <div class="row">
        <div class="col-12 form-group">
            <label for="">Nombre</label>
            <input type="text" name="nombre" class="form-control">
        </div>
    </div>
    <div class="row">
        <div class="col-12 form-group">
            <label for="">Compra</label>
            <input type="number" name="compra" class="form-control">
        </div>
    </div>
    <div class="row">
        <div class="col-12 form-group">
            <label for="">Venta</label>
            <input type="number" name="venta" class="form-control">
        </div>
    </div>
    <div class="row">
        <div class="col-12 form-group">
            <label for="">Stock</label>
            <input type="number" name="stock" class="form-control">
        </div>
    </div>
    <button type="submit" class="btn btn-primary">Registrar</button>
</form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>