<div class="modal-header">
    <h5 class="modal-title">Productos que coinciden <?php echo e($busqueda); ?></h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
    </button>
</div>
<div class="modal-body">
    <table class="table table-striped tabla-productos">
        <thead>
            <tr>
                <th scope="col">Folio</th>
                <th scope="col">Nombre</th>
                <th scope="col">Precio</th>
                <th scope="col">Stock</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="producto" data-producto="<?php echo e(json_encode($producto)); ?>">
                <th scope="row"><?php echo e($producto->id); ?></th>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e($producto->venta); ?></td>
                <td><?php echo e($producto->stock); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="modal-footer">
    
</div>
