<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PruebaCorreo</title>
</head>
<body>
Se cerro la caja con un total de ventas de: {{$ventasTotales}}
<div>
    Con utilidades: {{$utilidades}}
</div>
<div>
    Reparaciones finales: {{$reparaciones_finales}}
</div>
<div>
    Fecha y hora de cierre: {{$fecha_hora_cierre}}
</div>
</body>
</html>