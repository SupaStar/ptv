<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AperturaCaja extends Model
{
    protected $table = "aperturas_caja";
}
