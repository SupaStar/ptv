<?php

namespace App\Http\Controllers;

use App\CategoriaProducto;
use App\Perfil;
use App\User;
use App\Venta;
use Carbon\Carbon;
use Illuminate\Http\Request;

class VentaProductoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

    }
}